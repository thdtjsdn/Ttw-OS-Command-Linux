
/*グループ1
------------------------------------------------------------*/



/*縦一行目のセル*/
table tr td:first-child {
			}

/*横一行目のセル*/
table tr:first-child {
			}

/* 会話レイアウト */

/*TOC+*/
#toc_container {
	
	}



/*マル数字olタグ*/


.post .maruno ol li:before {
		}

/*チェックulタグ*/


.post .maruck ul li:before {
		}

/*Webアイコン*/





/*スライドショー矢印非表示*/

/*サイト上部のボーダー色*/

/*ヘッダーの背景色*/

		#headbox {
							background-color: transparent;
							
					background: none;
										}

		

/*サイトの背景色*/

/*ヘッダー下からの背景色*/
#content-w {
                   
	}

/*メインコンテンツのテキスト色*/
.post > * {
	color: ;
}

input, textarea {
	color: #000;
}

/*メインコンテンツのリンク色*/

a, 
.no-thumbitiran h3 a, 
.no-thumbitiran h5 a {
	color: ;
}
/*サイドのテキスト色*/
#side aside > *, 
#side aside .kanren .clearfix dd h5 a,
#side aside .kanren .clearfix dd p {
	color: ;
}

/*メインコンテンツの背景色*/
main {
	background: #ffffff;
}

/*メイン背景色の透過*/


/*ブログタイトル*/

header .sitename a {
	color: #1a1a1a;
}

/* メニュー */
nav li a {
	color: #1a1a1a;
}

/*ページトップ*/
#page-top a {
	background: ;
}


/*キャプション */

header h1 {
	color: #1a1a1a;
}

header .descr {
	color: #1a1a1a;
}

/* アコーディオン */
#s-navi dt.trigger .op {
	background: ;
	color: ;
}


/*追加ボタン1*/
#s-navi dt.trigger .op-st {
		}

/*追加ボタン2*/
#s-navi dt.trigger .op-st2 {
		}

.acordion_tree li a {
	color: #1a1a1a;
}


/*スマホフッターメニュー*/
#st-footermenubox a {
	color: #000; 
}


/* サイド見出し */
aside h4 {
	color: #1a1a1a;
}

/* スマホメニュー文字 */
.acordion_tree ul.menu li a, 
.acordion_tree ul.menu li {
	color: #000000;
}

.acordion_tree ul.menu li {
	border-bottom-color: #000000;
}

/*グループ2
------------------------------------------------------------*/
/*Webフォント*/
	.rankh3-in, 
	.rankh4, .post .rankh4, #side .rankh4,
	.entry-title, 
	.post .entry-title, 
	.kanren .clearfix dd h5 a, 
	h5.poprank-noh5 a, 
	.no-thumbitiran h5 a {
		font-family: Josefin Sans, Julius Sans One, 'Meddon', Lobster, Pacifico, Fredericka the Great, Bilbo Swash Caps, PT Sans Caption, Montserrat, "メイリオ", Meiryo, "ヒラギノ角ゴ Pro W3", Hiragino Kaku Gothic Pro, "ＭＳ Ｐゴシック", sans-serif !important;
	}







/* 投稿日時・ぱんくず・タグ */
#breadcrumb, #breadcrumb div a, div#breadcrumb a, .blogbox p, .tagst, #breadcrumb ol li a, #breadcrumb ol li {
	color: #dbdbdb;
}

/* 記事タイトル */
	.entry-title, .post .entry-title {
		font-family: Josefin Sans, Julius Sans One, 'Meddon', Lobster, Pacifico, Fredericka the Great, Bilbo Swash Caps, PT Sans Caption, Montserrat, "メイリオ", Meiryo, "ヒラギノ角ゴ Pro W3", Hiragino Kaku Gothic Pro, "ＭＳ Ｐゴシック", sans-serif !important;
	}


	.entry-title, .post .entry-title {
		color: #000000;
					background-color: transparent;
						
				background: none;
						}


	.entry-title, .post .entry-title {
		padding-left:10px;
	}

	.entry-title, .post .entry-title {
		padding-top:5px;
		padding-bottom:5px;
	}





	.entry-title, .post .entry-title {
		padding-left:10px!important;
	}

	.entry-title, .post .entry-title {
		padding-top:5px!important;
		padding-bottom:5px!important;
	}

/* h2 */


	h2 {
		color: ;
					background-color: transparent;
						
				background: none;
					
					border: none;
			}

	

	h2 {
		padding-left:20px!important;
	}

	h2 {
		padding-top:10px!important;
		padding-bottom:10px!important;
	}

/*h3小見出し*/


	.post h3:not(.rankh3):not(#reply-title) {
		color: ;
		border-bottom-color: ;
	
		
		
					background-color: transparent;
			}


	.post h3:not(.rankh3):not(#reply-title) {
		padding-left:15px!important;
	}

	.post h3:not(.rankh3):not(#reply-title) {
		padding-top:10px!important;
		padding-bottom:10px!important;
	}

/*h4*/
.post h4:not(.rankh4):not(.point) {
		color: ;
			background-color: transparent;
	
	
	
			padding-left:20px;
	
			padding-top:10px;
		padding-bottom:10px;
	
	}

/* サイド見出し */
aside h4, #side aside h4 {
	color: ;
}

/*h5*/
.post h5:not(.rankh5):not(.point):not(.st-cardbox-t):not(.popular-t):not(.kanren-t) {
		color: ;
			background-color: transparent;
	
	
	
	
			padding-top:10px!important;
		padding-bottom:10px!important;
	
	}

/* タグクラウド */
.tagcloud a {
	border-color: ;
	color: ;
}

/* NEW ENTRY & 関連記事 */
.post h4:not(.rankh4).point, 
.cat-itiran p.point,
.n-entry-t {
	border-bottom-color: ;
}

.post h4:not(.rankh4) .point-in, 
.cat-itiran p.point .point-in,
.n-entry {
	background-color: ;
	color: ;
}

/* カテゴリ */
.catname {
	background: ;
	color:#000000;
}

.post .st-catgroup a {
	color: #000000;
}

/*グループ4
------------------------------------------------------------*/
/* RSSボタン */
.rssbox a {
	background-color: ;
}

/* SNSボタン */


.inyoumodoki, .post blockquote {
	background-color: #f3f3f3;
	border-left-color: #f3f3f3;
}

/*フリーボックスウィジェット
------------------------------------------------------------*/
/* ボックス */
.freebox {
	border-top-color: ;
	background: ;
}

/* 見出し */
.p-entry-f {
	background: ;
	color: ;
}

/* エリア内テキスト */

/*お知らせ
------------------------------------------------------------*/
/*お知らせバーの背景色*/
#topnews-box div.rss-bar {
			border: none;
	}

#topnews-box div.rss-bar {
	color: ;

	/*Other Browser*/
	background: ;
	/*For Old WebKit*/
	background: -webkit-linear-gradient(  0%,  100% );
	/*For Modern Browser*/
	background: linear-gradient(  0%,  100% );
}

/*お知らせ日付の文字色*/
#topnews-box dt {
	color: ;
}

#topnews-box div dl dd a {
	color: #000000;
}

#topnews-box dd {
	border-bottom-color: #000000;
}

#topnews-box {
			background-color:transparent!important;
	}

/*追加カラー
------------------------------------------------------------*/
/*フッター*/
footer > *,
footer a,
#footer .copyr,  
#footer .copyr a, 
#footer .copy,  
#footer .copy a {
	}

footer .footermenust li {
	border-right-color:  !important;
}

/*フッター背景色*/

	#footer {
					background-color: transparent;
						
				background: none;
						            
           					max-width: 1084px; /*padding 15pxあり*/
			}

	

/*任意の人気記事
------------------------------------------------------------*/

.post .p-entry, #side .p-entry, .home-post .p-entry {
	background: ;
	color: ;
}

.pop-box, .nowhits .pop-box, .nowhits-eye .pop-box {
	border-top-color: ;
	background: ;
}

.kanren.pop-box .clearfix dd h5 a, 
.kanren.pop-box .clearfix dd p,
.kanren.pop-box .clearfix dd p a, 
.kanren.pop-box .clearfix dd p span, 
.kanren.pop-box .clearfix dd > *,
.kanren.pop-box h5 a, 
.kanren.pop-box div p,
.kanren.pop-box div p a, 
.kanren.pop-box div p span, 
.kanren.pop-box div > *
{
	color: !important;
}

	.poprank-no2 {
		background: ;
		color:  !important;
	}

	.poprank-no {
		background: ;
		color: ;
	}

/*ウィジェット問合せボタン*/

.st-formbtn {
	
	
			background-color: transparent!important;
	}

.st-formbtn .st-originalbtn-r {
	border-left-color: ;
}

a.st-formbtnlink {
	color: ;
}

/*ウィジェットオリジナルボタン*/

.st-originalbtn {
	
	
			background-color: transparent!important;
	}

.st-originalbtn .st-originalbtn-r {
	border-left-color: ;
}

a.st-originallink {
	color: ;
}

/*固定ページサイドメニュー
------------------------------------------------------------*/
/*背景色*/
#sidebg {
	background: ;

	}


	/*liタグの階層*/
	#side aside .st-pagelists ul li:not(.sub-menu) {
					border-top: none;
		
					border-left: none;
			border-right: none;
			}

	#side aside .st-pagelists ul .sub-menu li {
		border: none;
	}

	#side aside .st-pagelists ul li:last-child {
					border-bottom: none;
			}

	#side aside .st-pagelists ul .sub-menu li:first-child {
					border-top: none;
			}

	#side aside .st-pagelists ul li li:last-child {
		border: none;
	}

	#side aside .st-pagelists ul .sub-menu .sub-menu li {
		border: none;
	}
	
	#side aside .st-pagelists ul li a {
		color: ;
					background-color: transparent;
						
				background: none;
						}

	
	#side aside .st-pagelists .sub-menu a {
					border: none;
				color: ;
	}

	#side aside .st-pagelists .sub-menu .sub-menu li:last-child {
		border-bottom: 1px solid ;
	}

	#side aside .st-pagelists .sub-menu li .sub-menu a,
	#side aside .st-pagelists .sub-menu li .sub-menu .sub-menu li a {
		color: ;
	}



	#side aside .st-pagelists ul li a {
		padding-left:15px;
	}

	#side aside .st-pagelists ul li a {
		padding-top:8px;
		padding-bottom:8px;
	}

/*Webアイコン*/


/*コンタクトフォーム7送信ボタン*/
.wpcf7-submit {
	background: ;
	color: ;
}

/* メイン画像背景色 */


/*media Queries タブレットサイズ（959px以下）
----------------------------------------------------*/
@media only screen and (max-width: 959px) {

	/*-- ここまで --*/
}

/*media Queries タブレットサイズ以下
----------------------------------------------------*/
@media only screen and (min-width: 600px) {

}

/*media Queries タブレットサイズ（600px～959px）のみで適応したいCSS -タブレットのみ
---------------------------------------------------------------------------------------------------*/
@media only screen and (min-width: 600px) and (max-width: 959px) {

	
/*-- ここまで --*/
}


/*media Queries PCサイズ
----------------------------------------------------*/
@media only screen and (min-width: 960px) {

	

	
	/*ヘッダーの背景色*/
	
	/*メインコンテンツのボーダー*/
	
	
	/* メイン画像100% */
	

	/* スライドショー横並び */
	
	/*wrapperに背景がある場合*/
	
	/*メニュー*/
	#st-menuwide {
			border-top: none;
		border-bottom: none;
				border-left: none;
		border-right: none;
	
			background-color: transparent;
					
			background: none;
				}

	

	header .smanone ul.menu li, 
	header nav.st5 ul.menu  li,
	header nav.st5 ul.menu  li,
	header #st-menuwide div.menu li,
	header #st-menuwide nav.menu li
	{
			border-right: none;
		}

	header .smanone ul.menu li, 
	header nav.st5 ul.menu  li,
	header #st-menuwide div.menu li,
	header #st-menuwide nav.menu li {
		border-right-color: ;
	}

	header .smanone ul.menu li a, 
	header nav.st5 ul.menu  li a,
	header #st-menuwide div.menu li a,
	header #st-menuwide nav.menu li a {
		color: ;
	}

	
	header .smanone ul.menu li li a {
		background: ;
		border-top-color: ;

	}

	/*メニューの上下のパディング*/
		

	/* グローバルメニュー100% */
	
	/*ヘッダーウィジェット*/
	header .headbox .textwidget {
		background: ;
		color: #000000;
	}

	/*ヘッダーの電話番号とリンク色*/
	.head-telno a, #header-r .footermenust a {
		color: #000000;
	}

	#header-r .footermenust li {
		border-right-color: #000000;
	}

	/*トップ用おすすめタイトル*/
	.nowhits .pop-box {
		border-top-color: ;
	}

	/*記事エリアを広げる*/
	
	/*記事タイトル*/
	.entry-title, .post .entry-title {
		color: #000000;
							
			}

/*-- ここまで --*/
}
